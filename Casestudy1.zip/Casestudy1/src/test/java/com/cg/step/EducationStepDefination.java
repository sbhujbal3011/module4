package com.cg.step;

import org.junit.Assert;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.PageFactory;

import com.cg.bean.Education;

import cucumber.api.java.After;
import cucumber.api.java.Before;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class EducationStepDefination {
	private WebDriver driver;
	private Education education;

	@Before
	public void init() {
		// Instatntiate driver
		System.setProperty("webdriver.chrome.driver", "mydriver\\chromedriver.exe");
		
	}

	/*@After
	public void destroy() {
		driver.quit();
	}*/

	@Given("^User is on education details page$")
	public void user_is_on_education_details_page() throws Throwable {
		driver = new ChromeDriver();
		String url = "C:\\Users\\sbhujbal\\Workspacebdd\\Casestudy1\\html\\EducationalDetails.html";
		driver.get(url);
		education = new Education();
		PageFactory.initElements(driver, education);

	}

	@Then("^Validate education details page$")
	public void validate_education_details_page() throws Throwable {
		String expectedPageTitle = "Educational Details";
		String actualPageTitle = driver.getTitle();
		Assert.assertEquals(expectedPageTitle, actualPageTitle);
		Thread.sleep(3000);
		driver.close();
		

	}

	@When("^User selects graduation$")
	public void user_selects_graduation() throws Throwable {
		education.clickgraduate(0);

	}

	@Then("^Validate graduation$")
	public void validate_graduation() throws Throwable {
		education.clickMakePayment();
		Thread.sleep(2000);
		driver.switchTo().alert().accept();
		Thread.sleep(2000);
		driver.close();
	}

	@When("^User enters percentage$")
	public void user_enters_percentage() throws Throwable {
		education.clickgraduate(1);
		education.setPercentage("");
	}

	@Then("^Validate percentage$")
	public void validate_percentage() throws Throwable {
		education.clickMakePayment();
		Thread.sleep(2000);
		driver.switchTo().alert().accept();
		Thread.sleep(2000);
		driver.close();
	}

	@When("^User enters passingYear$")
	public void user_enters_passingYear() throws Throwable {
		education.clickgraduate(1);
		education.setPercentage("80");
		education.setpassingYear("");
	}

	@Then("^Validate passingYear$")
	public void validate_passingYear() throws Throwable {
		education.clickMakePayment();
		Thread.sleep(2000);
		driver.switchTo().alert().accept();
		Thread.sleep(2000);
		driver.close();
	}

	@When("^User enters projectName$")
	public void user_enters_projectName() throws Throwable {
		education.clickgraduate(1);
		education.setPercentage("80");
		education.setpassingYear("2017");
		education.setprojectName("");
	}

	@Then("^Validate projectName$")
	public void validate_projectName() throws Throwable {
		education.clickMakePayment();
		Thread.sleep(2000);
		driver.switchTo().alert().accept();
		Thread.sleep(2000);
		driver.close();
	}

	@When("^User enters technology$")
	public void user_enters_technology() throws Throwable {
		education.clickgraduate(1);
		education.setPercentage("80");
		education.setpassingYear("2017");
		education.setprojectName("crystography");
		education.clicktechnology(0);
	}

	@Then("^Validate technology$")
	public void validate_technology() throws Throwable {
		education.clickMakePayment();
		Thread.sleep(2000);
		driver.switchTo().alert().accept();
		Thread.sleep(2000);
		driver.close();
	}

	@When("^User clicks on MakePayment$")
	public void user_clicks_on_MakePayment() throws Throwable {
		education.clickgraduate(1);
		education.setPercentage("80");
		education.setpassingYear("2017");
		education.setprojectName("crystography");
		education.clicktechnology(1);

	}

	@Then("^Show successful educational detailsalert$")
	public void show_successful_educational_detailsalert() throws Throwable {
		education.clickMakePayment();
		Thread.sleep(2000);
		driver.switchTo().alert().accept();
		Thread.sleep(2000);
		driver.close();

	}

}
