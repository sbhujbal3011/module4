package com.cg.step;

import org.junit.Assert;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.PageFactory;

import com.cg.bean.Personal;

import cucumber.api.java.After;
import cucumber.api.java.Before;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class PersonalStepDefination {

	private WebDriver driver;
	private Personal personal;

	@Before
	public void init() {
		// Instatntiate driver
		System.setProperty("webdriver.chrome.driver", "mydriver\\chromedriver.exe");
		
		/*String currentWindow=driver.getWindowHandle();
		driver.switchTo().window(currentWindow);*/
	}

	/*@After
	public void destroy() {
		driver.quit();
	}*/

	@Given("^User is on personal details page$")
	public void user_is_on_personal_details_page() throws Throwable {
		driver = new ChromeDriver();
		String url = "C:\\Users\\sbhujbal\\Workspacebdd\\Casestudy1\\html\\PersonalDetails.html";
		driver.get(url);
		personal = new Personal();
		PageFactory.initElements(driver, personal);

	}

	@Then("^Validate personal details page$")
	public void validate_personal_details_page() throws Throwable {
		String expectedPageTitle = "Personal Details";
		String actualPageTitle = driver.getTitle();
		Assert.assertEquals(expectedPageTitle, actualPageTitle);
		Thread.sleep(3000);
		driver.close();
	}

	@When("^User enters first name$")
	public void user_enters_first_name() throws Throwable {
		personal.setfirstname("");
	}

	@Then("^Validate first name$")
	public void validate_first_name() throws Throwable {
		personal.clicknextButton();
		Thread.sleep(2000);
		driver.switchTo().alert().accept();
		Thread.sleep(2000);
		driver.close();
	}

	@When("^User enters last name$")
	public void user_enters_last_name() throws Throwable {
		personal.setfirstname("shreya");
		personal.setlastname("");

	}

	@Then("^Validate last name$")
	public void validate_last_name() throws Throwable {
		personal.clicknextButton();
		Thread.sleep(2000);
		driver.switchTo().alert().accept();
		Thread.sleep(2000);
		driver.close();
	}

	@When("^User enters email$")
	public void user_enters_email() throws Throwable {
		personal.setfirstname("shreya");
		personal.setlastname("bhujbal");
		personal.setemail("abcd");

	}

	@Then("^Validate email$")
	public void validate_email() throws Throwable {
		personal.clicknextButton();
		Thread.sleep(2000);
		driver.switchTo().alert().accept();
		Thread.sleep(2000);
		driver.close();

	}

	@When("^Empty contact number$")
	public void empty_contact_number() throws Throwable {
		personal.setfirstname("shreya");
		personal.setlastname("bhujbal");
		personal.setemail("shre@gmail.com");
		personal.setcontact("");
	}

	@When("^User enters contact number$")
	public void user_enters_contact_number() throws Throwable {
		personal.setfirstname("shreya");
		personal.setlastname("bhujbal");
		personal.setemail("shre@gmail.com");
		personal.setcontact("222");

	}

	@Then("^Validate contact number$")
	public void validate_contact_number() throws Throwable {
		personal.clicknextButton();
		Thread.sleep(2000);
		driver.switchTo().alert().accept();
		Thread.sleep(2000);
		driver.close();
	}

	@When("^User enters address(\\d+)$")
	public void user_enters_address(int arg1) throws Throwable {
		personal.setfirstname("shreya");
		personal.setlastname("bhujbal");
		personal.setemail("shre@gmail.com");
		personal.setcontact("9405517612");
		personal.setaddress1("");
		personal.setaddress2("");
	}

	@Then("^Validate address(\\d+)$")
	public void validate_address(int arg1) throws Throwable {
		personal.clicknextButton();
		Thread.sleep(2000);
		driver.switchTo().alert().accept();
		Thread.sleep(2000);
		driver.close();
	}

	@When("^User selects city$")
	public void user_selects_city() throws Throwable {
		personal.setfirstname("shreya");
		personal.setlastname("bhujbal");
		personal.setemail("shre@gmail.com");
		personal.setcontact("9405517612");
		personal.setaddress1("sahakar nagar");
		personal.setaddress2("swargate");
		personal.clickcity(0);
		// personal.clicknextButton();

	}

	@Then("^Validate city$")
	public void validate_city() throws Throwable {
		personal.clicknextButton();
		Thread.sleep(2000);
		driver.switchTo().alert().accept();
		Thread.sleep(2000);
		driver.close();
	}

	@When("^User selects state$")
	public void user_selects_state() throws Throwable {
		personal.setfirstname("shreya");
		personal.setlastname("bhujbal");
		personal.setemail("shre@gmail.com");
		personal.setcontact("9405517612");
		personal.setaddress1("sahakar nagar");
		personal.setaddress2("swargate");
		personal.clickcity(1);
		personal.clickstate(0);
		// personal.clicknextButton();

	}

	@Then("^Validate state$")
	public void validate_state() throws Throwable {
		personal.clicknextButton();
		Thread.sleep(2000);
		driver.switchTo().alert().accept();
		Thread.sleep(2000);
		driver.close();
	}

	@When("^User clicks on Next button$")
	public void user_clicks_on_Next_button() throws Throwable {
		personal.setfirstname("shreya");
		personal.setlastname("bhujbal");
		personal.setemail("shre@gmail.com");
		personal.setcontact("9405517612");
		personal.setaddress1("sahakar nagar");
		personal.setaddress2("swargate");
		personal.clickcity(1);
		personal.clickstate(1);

	}

	@Then("^Show successful alert$")
	public void show_successful_alert() throws Throwable {
		personal.clicknextButton();
		Thread.sleep(2000);
		driver.switchTo().alert().accept();
		Thread.sleep(2000);
		driver.close();
	}

}
