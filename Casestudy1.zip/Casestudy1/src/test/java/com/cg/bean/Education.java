package com.cg.bean;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.Select;

public class Education {
/*	@FindBy(id = "remember")
	WebElement remember;*/

	@FindBy(id = "graduate")
	WebElement graduate;

	@FindBy(id = "percentage")
	WebElement percentage;

	@FindBy(id = "passingYear")
	WebElement passingYear;

	@FindBy(id = "projectName")
	WebElement projectName;

	@FindBy(id = "technology")
	WebElement technology;

	@FindBy(id = "MakePayment")
	WebElement MakePayment;

	public void clickgraduate(int idx) {
		Select select = new Select(graduate);
		select.selectByIndex(idx);
	}

	public String getpercentage() {
		return this.percentage.getAttribute("value");
	}

	public void setPercentage(String percentage) {
		this.percentage.sendKeys(percentage);
	}

	public String getpassingYear() {
		return this.passingYear.getAttribute("value");
	}

	public void setpassingYear(String passingYear) {
		this.passingYear.sendKeys(passingYear);
	}

	public String getprojectName() {
		return this.projectName.getAttribute("value");
	}

	public void setprojectName(String projectName) {
		this.projectName.sendKeys(projectName);
	}

	/*public String gettechnology() {
		return this.technology.getAttribute("value");
	}

	public void settechnology(String technology) {
		this.technology.sendKeys(technology);
	}*/

	public void clickMakePayment() {
		MakePayment.click();
	}
	public void clicktechnology(int idx1) {
		Select select = new Select(technology);
		select.selectByIndex(idx1);
	}
}
