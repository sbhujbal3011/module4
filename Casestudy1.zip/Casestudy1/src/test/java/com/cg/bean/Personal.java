package com.cg.bean;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.Select;

public class Personal {

	@FindBy(id = "firstname")
	WebElement firstname;

	@FindBy(id = "lastname")
	WebElement lastname;

	@FindBy(id = "email")
	WebElement email;

	@FindBy(id = "contact")
	WebElement contact;

	@FindBy(id = "address1")
	WebElement address1;

	@FindBy(id = "address2")
	WebElement address2;

	@FindBy(id = "city")
	WebElement city;

	@FindBy(id = "state")
	WebElement state;

	@FindBy(id = "next")
	WebElement next;

	public String getfirstname() {
		return this.firstname.getAttribute("value");
	}

	public void setfirstname(String firstname) {
		this.firstname.sendKeys(firstname);
	}

	public String getlastname() {
		return this.lastname.getAttribute("value");
	}

	public void setlastname(String lastName) {
		this.lastname.sendKeys(lastName);
	}

	public String getemail() {
		return this.email.getAttribute("value");
	}

	public void setemail(String email) {
		this.email.sendKeys(email);
	}

	public String getcontact() {
		return this.contact.getAttribute("value");
	}

	public void setcontact(String contact) {
		this.contact.sendKeys(contact);
	}

	public String getaddress1() {
		return this.address1.getAttribute("value");
	}

	public void setaddress1(String address1) {
		this.address1.sendKeys(address1);
	}

	public String getaddress2() {
		return this.address2.getAttribute("value");
	}

	public void setaddress2(String address2) {
		this.address2.sendKeys(address2);
	}
	
	public void clickcity(int idx) {
		Select select = new Select(city);
		select.selectByIndex(idx);
	}
	
	public void clickstate(int idx1) {
		Select select = new Select(state);
		select.selectByIndex(idx1);
	}
	public void clicknextButton() {
		next.click();
	}
	

}
