package com.cg.step;

import cucumber.api.java.After;
import cucumber.api.java.Before;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class HelloStepDefination {
	@Before
	public void init() {
		System.out.println("Scenario test begin");
	}
	
	@After
	public void destroy() {
		System.out.println("senario test end");
	}
	
	@Given("^Attended training$")
	public void attendedTraining() throws Throwable {
	   System.out.println("1-Attended Training");
	  
	}

	@When("^Clear L(\\d+)$")
	public void clearL1(int arg1) throws Throwable {
	   System.out.println("2-clear l1");
	}

	@Then("^Beacame employe$")
	public void beacameEmploye() throws Throwable {
	    System.out.println("I am slave");
	}
	@Before
	public void init1() {
		System.out.println("Scenario test begin1");
	}
	
	@After
	public void destroy1() {
		System.out.println("senario test end1");
	}

	@Given("^Hello given step$")
	public void HelloGivenstep() throws Throwable {
		System.out.println("saying hello to given step");
	}

	@Given("^Hello when step$")
	public void HelloWhenStep() throws Throwable {
		System.out.println("saying hello when this step");
	}

	@Given("^Hello then step$")
	public void HelloThenStep() throws Throwable {
		System.out.println("saying hello when this step");
	}
	
	
	
	@Given("^Bye given step$")
	public void ByeGivenStep() throws Throwable {
		System.out.println("saying Bye to given step");
	}

	@Given("^Bye when step$")
	public void ByeWhenStep() throws Throwable {
		System.out.println("saying Bye when this step");
	}

	@Given("^Bye then step$")
	public void ByeThenStep() throws Throwable {
		System.out.println("saying Bye when this step");
	}
}
