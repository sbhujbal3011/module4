package com.cg.step;


import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

import cucumber.api.java.Before;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class LoginStepDefination {
	private WebDriver driver;

	@Before
	public void init() {
		// Instatntiate driver
		System.setProperty("webdriver.chrome.driver", "mydriver\\chromedriver.exe");
		driver = new ChromeDriver();
	}

	@Given("^User is on login page$")
	public void user_is_on_login_page() throws Throwable {
		// Write code here that turns the phrase above into concrete actions
		String url = "file:///C:\\Users\\sbhujbal\\Workspacebdd\\HelloBddnew\\html\\login.html";
		driver.get(url);
	}

	@When("^User enters username details$")
	public void user_enters_username_details() throws Throwable {
		// Write code here that turns the phrase above into concrete actions
		WebElement uname = driver.findElement(By.id("username"));
		uname.sendKeys("Varsha");
	}

	@Then("^Validate username$")
	public void validate_username() throws Throwable {
		// Write code here that turns the phrase above into concrete actions

	}

	@When("^User enters password details$")
	public void user_enters_password_details() throws Throwable {
		// Write code here that turns the phrase above into concrete actions
		WebElement pwd = driver.findElement(By.id("password"));
		pwd.sendKeys("oracle");
	}

	@Then("^Validate password$")
	public void validate_password() throws Throwable {
		// Write code here that turns the phrase above into concrete actions

	}

	@When("^User click on submit form$")
	public void user_click_on_submit_form() throws Throwable {
		// Write code here that turns the phrase above into concrete actions

	}

	@Then("^Show successfully submitted$")
	public void show_successfully_submitted() throws Throwable {
		// Write code here that turns the phrase above into concrete actions
		WebElement form = driver.findElement(By.tagName("form"));
		form.submit();
		Thread.sleep(2000);
		driver.switchTo().alert().accept();
		Thread.sleep(2000);
	}

}
